"""
enroll.py — enrollment flow for SVM approach

Runs the structured 5-minute typing and interaction test:
  Segment 1 (2 min): pangram repetition — pure timing signal
  Segment 2 (2 min): natural free-form typing
  Segment 3 (1 min): structured interactions — click, scroll, and calibrate
"""

import time
import numpy as np
from dataclasses import dataclass
from typing import Optional

from collector import RawCollector
from features import (
    extract_keystroke_pairs, pairs_to_window,
    extract_statistical_features, WindowNormalizer, WINDOW_SIZE,
)
from model import (
    UserProfile, train_svm_model, calibrate_svm_thresholds,
)

PANGRAMS = [
    "the quick brown fox jumps over the lazy dog",
    "pack my box with five dozen liquor jugs",
    "how vexingly quick daft zebras jump",
    "the five boxing wizards jump quickly",
    "sphinx of black quartz judge my vow",
]

SEGMENT_DURATIONS = {
    "pangram":   120,   # 2 minutes
    "freeform":  120,   # 2 minutes
    "calibrate":  60,   # 1 minute
}


@dataclass
class EnrollmentResult:
    subject_id: str
    profile: UserProfile
    n_enrollment_windows: int
    n_calibration_windows: int
    estimated_eer_hint: str


def run_enrollment(subject_id: str, device: str = "cpu") -> EnrollmentResult:
    """
    Full enrollment flow. Blocks for ~5 minutes.
    Returns a trained SVM UserProfile.
    """
    collector = RawCollector()
    collector.start()

    segment_events: dict[str, list] = {
        "pangram": [], "freeform": [], "calibrate": []
    }
    segment_mouse_events: dict[str, list] = {
        "pangram": [], "freeform": [], "calibrate": []
    }

    # ── segment 1: pangram repetition ─────────────────────────────────────
    print("\n=== BehaveGuard Enrollment (SVM Baseline) ===")
    print("\nSegment 1/3 — Pangram repetition (2 minutes)")
    print("Type the following sentences. Repeat them as many times as you like.")
    for p in PANGRAMS:
        print(f"  → {p}")
    print("\nStart typing now...\n")

    _collect_segment(collector, segment_events["pangram"], segment_mouse_events["pangram"],
                     duration=SEGMENT_DURATIONS["pangram"])

    # ── segment 2: free-form typing ────────────────────────────────────────
    print("\nSegment 2/3 — Natural typing (2 minutes)")
    print("Type anything freely — describe your day, thoughts, copy-paste or write anything.")
    print("Start typing now...\n")

    _collect_segment(collector, segment_events["freeform"], segment_mouse_events["freeform"],
                     duration=SEGMENT_DURATIONS["freeform"])

    # ── segment 3: calibration (held out) ─────────────────────────────────
    print("\nSegment 3/3 — Calibration (1 minute, held out for thresholds)")
    print("Please type the following calibration phrases:")
    for p in PANGRAMS[:2]:
        print(f"     → {p}")
    print("\nStart typing now...\n")

    _collect_segment(collector, segment_events["calibrate"], segment_mouse_events["calibrate"],
                     duration=SEGMENT_DURATIONS["calibrate"])

    collector.stop()
    print("\nInteractions complete. Training model...")

    # ── feature extraction ─────────────────────────────────────────────────
    train_events = segment_events["pangram"] + segment_events["freeform"]
    cal_events   = segment_events["calibrate"]

    train_pairs = extract_keystroke_pairs(train_events)
    cal_pairs   = extract_keystroke_pairs(cal_events)

    train_windows = _make_windows(train_pairs)
    cal_windows   = _make_windows(cal_pairs)

    if len(train_windows) < 10:
        raise ValueError(
            f"Not enough training data. Got {len(train_windows)} windows, "
            f"need at least 10 (approx. 200–300 keystrokes). Please type faster/more next time."
        )
    if len(cal_windows) < 3:
        raise ValueError(
            f"Not enough calibration data. Got {len(cal_windows)} windows. "
            f"Please interact/type more during the final segment."
        )

    # Convert windows [WINDOW_SIZE, 11] to flat statistical features [43]
    train_stats = [extract_statistical_features(w) for w in train_windows]

    # ── normalisation ──────────────────────────────────────────────────────
    normalizer = WindowNormalizer()
    train_normed = normalizer.fit_transform(train_stats)

    # ── train model ────────────────────────────────────────────────────────
    # Default to One-Class SVM with nu=0.05
    model = train_svm_model(train_normed, kernel="rbf", nu=0.05)
    print(f"  One-Class SVM model trained on {len(train_normed)} windows.")

    # ── calibrate thresholds ───────────────────────────────────────────────
    # Calibrate thresholds using the held-out calibration raw windows
    T_anomaly, T_drift, enrollment_mean, enrollment_cov = calibrate_svm_thresholds(
        model, normalizer, cal_windows
    )
    print(f"  T_anomaly={T_anomaly:.4f}  T_drift={T_drift:.4f}")

    # ── assemble profile ───────────────────────────────────────────────────
    profile = UserProfile(
        subject_id=subject_id,
        model=model,
        normalizer=normalizer,
        T_anomaly=T_anomaly,
        T_drift=T_drift,
        enrollment_mean=enrollment_mean,
        enrollment_cov=enrollment_cov,
        enrolled_at=time.time(),
    )

    quality = "good" if len(train_normed) >= 30 else "minimal — consider longer enrollment"

    print(f"\nEnrollment complete for '{subject_id}'.")
    print(f"  Training windows : {len(train_normed)}")
    print(f"  Calibration windows: {len(cal_normed)}")
    print(f"  Quality: {quality}")

    return EnrollmentResult(
        subject_id=subject_id,
        profile=profile,
        n_enrollment_windows=len(train_normed),
        n_calibration_windows=len(cal_normed),
        estimated_eer_hint=quality,
    )


def _collect_segment(collector: RawCollector,
                      key_list: list,
                      mouse_list: list,
                      duration: float):
    """Drain collector into event lists for `duration` seconds."""
    end_time = time.time() + duration
    last_print = time.time()

    while time.time() < end_time:
        kb_events, mouse_events = collector.drain()
        key_list.extend(kb_events)
        mouse_list.extend(mouse_events)
        time.sleep(0.1)

        # progress tick every 15 seconds
        if time.time() - last_print > 15:
            remaining = int(end_time - time.time())
            print(f"  {remaining}s remaining... ({len(key_list)} keys captured)")
            last_print = time.time()


def _make_windows(pairs: list) -> list[np.ndarray]:
    """Slide a window over pairs with 50% overlap."""
    step = WINDOW_SIZE // 2
    windows = []
    for start in range(0, len(pairs) - WINDOW_SIZE + 1, step):
        chunk = pairs[start: start + WINDOW_SIZE]
        w = pairs_to_window(chunk)
        if w is not None:
            windows.append(w)
    return windows

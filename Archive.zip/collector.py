"""
collector.py — raw event capture
Captures [key_code, press_ts, release_ts] and mouse events.
Key characters are NEVER stored — only timing metadata.
"""

import time
import threading
import queue
from dataclasses import dataclass, field
from typing import Optional
from pynput import keyboard, mouse


# ── data structures ──────────────────────────────────────────────────────────

@dataclass
class KeyEvent:
    key_code: str          # physical key name, not character
    key_category: str      # alphanum | symbol | special
    press_ts: float        # unix timestamp seconds
    release_ts: float      # unix timestamp seconds

    @property
    def dwell_ms(self) -> float:
        return (self.release_ts - self.press_ts) * 1000.0


@dataclass
class MouseEvent:
    action: str            # MM | PC | C | DD | S
    x: int
    y: int
    timestamp: float
    button: Optional[str] = None
    scroll_dx: float = 0.0
    scroll_dy: float = 0.0
    press_ts: Optional[float] = None   # for click dwell


# ── key categorisation ───────────────────────────────────────────────────────

def categorise_key(key) -> tuple[str, str]:
    """
    Returns (key_code, category) without storing the actual character.
    Category: alphanum | symbol | special_nav | special_edit | special_mod
    """
    try:
        char = key.char
        if char is None:
            raise AttributeError
        if char.isalpha():
            return "alphanum", "alphanum"
        elif char.isdigit():
            return "digit", "alphanum"
        else:
            return "symbol", "symbol"
    except AttributeError:
        name = str(key).replace("Key.", "").lower()
        if name in ("space",):
            return "space", "special_nav"
        elif name in ("enter", "return"):
            return "enter", "special_nav"
        elif name in ("backspace", "delete"):
            return "backspace", "special_edit"
        elif name in ("shift", "shift_r", "shift_l"):
            return "shift", "special_mod"
        elif name in ("ctrl", "ctrl_r", "ctrl_l"):
            return "ctrl", "special_mod"
        elif name in ("alt", "alt_r", "alt_l"):
            return "alt", "special_mod"
        elif name in ("tab",):
            return "tab", "special_nav"
        else:
            return name, "special_other"


# ── collector ────────────────────────────────────────────────────────────────

class RawCollector:
    """
    Collects raw keyboard and mouse events into a thread-safe queue.
    Never stores key characters — only timing and category.

    Usage:
        collector = RawCollector()
        collector.start()
        # ... later ...
        kb_events, mouse_events = collector.drain()
        collector.stop()
    """

    def __init__(self):
        self._key_queue: queue.Queue = queue.Queue()
        self._mouse_queue: queue.Queue = queue.Queue()
        self._press_times: dict = {}          # key_code → press_ts
        self._mouse_press_time: dict = {}     # button → press_ts
        self._last_mouse_pos: Optional[tuple] = None
        self._kb_listener: Optional[keyboard.Listener] = None
        self._mouse_listener: Optional[mouse.Listener] = None
        self._lock = threading.Lock()
        self._running = False

    # ── keyboard ──────────────────────────────────────────────────────────

    def _on_press(self, key):
        ts = time.time()
        code, _ = categorise_key(key)
        with self._lock:
            self._press_times[code] = ts

    def _on_release(self, key):
        ts = time.time()
        code, category = categorise_key(key)
        with self._lock:
            press_ts = self._press_times.pop(code, None)
        if press_ts is not None:
            event = KeyEvent(
                key_code=code,
                key_category=category,
                press_ts=press_ts,
                release_ts=ts,
            )
            self._key_queue.put(event)

    # ── mouse ─────────────────────────────────────────────────────────────

    def _on_move(self, x, y):
        ts = time.time()
        event = MouseEvent(action="MM", x=x, y=y, timestamp=ts)
        self._mouse_queue.put(event)

    def _on_click(self, x, y, button, pressed):
        ts = time.time()
        btn_name = str(button).replace("Button.", "")
        if pressed:
            self._mouse_press_time[btn_name] = ts
            event = MouseEvent(action="C", x=x, y=y, timestamp=ts,
                               button=btn_name, press_ts=ts)
        else:
            press_ts = self._mouse_press_time.pop(btn_name, ts)
            event = MouseEvent(action="PC", x=x, y=y, timestamp=ts,
                               button=btn_name, press_ts=press_ts)
        self._mouse_queue.put(event)

    def _on_scroll(self, x, y, dx, dy):
        ts = time.time()
        event = MouseEvent(action="S", x=x, y=y, timestamp=ts,
                           scroll_dx=float(dx), scroll_dy=float(dy))
        self._mouse_queue.put(event)

    # ── lifecycle ─────────────────────────────────────────────────────────

    def start(self):
        if self._running:
            return
        self._running = True
        self._kb_listener = keyboard.Listener(
            on_press=self._on_press,
            on_release=self._on_release,
        )
        self._kb_listener.start()

    def stop(self):
        self._running = False
        if self._kb_listener:
            self._kb_listener.stop()

    def drain(self) -> tuple[list[KeyEvent], list[MouseEvent]]:
        """Drain all queued events. Call periodically from your main loop."""
        kb_events: list[KeyEvent] = []
        mouse_events: list[MouseEvent] = []

        while not self._key_queue.empty():
            try:
                kb_events.append(self._key_queue.get_nowait())
            except queue.Empty:
                break

        while not self._mouse_queue.empty():
            try:
                mouse_events.append(self._mouse_queue.get_nowait())
            except queue.Empty:
                break

        return kb_events, mouse_events

"""
features.py — extract model-ready feature vectors from raw events
"""

import math
import time
import numpy as np
import scipy.stats
from dataclasses import dataclass
from typing import Optional
from collector import KeyEvent, MouseEvent

# ── constants ────────────────────────────────────────────────────────────────

WINDOW_SIZE = 50            # keystroke pairs per window (minimum)
MOUSE_WINDOW_SIZE = 30      # mouse events per window

# key category → one-hot index
KEY_CAT_INDEX = {
    "alphanum":      0,
    "symbol":        1,
    "special_nav":   2,
    "special_edit":  3,
    "special_mod":   4,
}

# action → one-hot index
ACTION_INDEX = {
    "MM": 0,
    "PC": 1,
    "C":  2,
    "DD": 3,
    "S":  4,
}

# approximate frequency of digraph categories (used as weight)
DIGRAPH_FREQ: dict[tuple, float] = {
    ("alphanum", "alphanum"):    1.0,   # most common, strongest signal
    ("alphanum", "special_nav"): 0.8,
    ("special_nav", "alphanum"): 0.7,
    ("alphanum", "symbol"):      0.5,
    ("symbol", "alphanum"):      0.5,
    ("alphanum", "special_edit"):0.4,
    ("special_mod", "alphanum"): 0.3,
}


# ── time encoding ─────────────────────────────────────────────────────────────

def encode_time(ts: float) -> tuple[float, float]:
    """
    Encode time-of-day as cyclical (sin, cos) features.
    """
    t = time.localtime(ts)
    fraction = (t.tm_hour * 60 + t.tm_min) / 1440.0
    return math.sin(2 * math.pi * fraction), math.cos(2 * math.pi * fraction)


def key_cat_onehot(category: str) -> list[float]:
    vec = [0.0] * len(KEY_CAT_INDEX)
    idx = KEY_CAT_INDEX.get(category, 0)
    vec[idx] = 1.0
    return vec


def action_onehot(action: str) -> list[float]:
    vec = [0.0] * len(ACTION_INDEX)
    idx = ACTION_INDEX.get(action, 0)
    vec[idx] = 1.0
    return vec


# ── keystroke feature extraction ─────────────────────────────────────────────

@dataclass
class KeystrokePair:
    """Features for one consecutive keystroke pair."""
    dwell_ms: float         # how long key A was held
    flight_ms: float        # gap between A release and B press (can be negative)
    digraph_ms: float       # A press → B press (down-to-down)
    key_cat_a: str          # category of first key
    key_cat_b: str          # category of second key
    timestamp: float        # when this pair occurred
    digraph_weight: float   # reliability weight [0,1]

    def to_vector(self) -> np.ndarray:
        t_sin, t_cos = encode_time(self.timestamp)
        vec = (
            [self.dwell_ms, self.flight_ms, self.digraph_ms]
            + key_cat_onehot(self.key_cat_a)    # 5 dims
            + [t_sin, t_cos, self.digraph_weight]
        )
        return np.array(vec, dtype=np.float32)   # shape [11]


def extract_keystroke_pairs(events: list[KeyEvent]) -> list[KeystrokePair]:
    """
    Convert a list of KeyEvents into consecutive pairs.
    """
    pairs = []
    for i in range(len(events) - 1):
        a, b = events[i], events[i + 1]

        dwell_ms   = a.dwell_ms
        flight_ms  = (b.press_ts - a.release_ts) * 1000.0
        digraph_ms = (b.press_ts - a.press_ts) * 1000.0

        # sanity bounds — discard physically impossible values
        if not (0 < dwell_ms < 2000):
            continue
        if not (-500 < flight_ms < 2000):
            continue
        if not (0 < digraph_ms < 3000):
            continue

        weight = DIGRAPH_FREQ.get((a.key_category, b.key_category), 0.2)

        pairs.append(KeystrokePair(
            dwell_ms=dwell_ms,
            flight_ms=flight_ms,
            digraph_ms=digraph_ms,
            key_cat_a=a.key_category,
            key_cat_b=b.key_category,
            timestamp=a.release_ts,
            digraph_weight=weight,
        ))
    return pairs


def pairs_to_window(pairs: list[KeystrokePair]) -> Optional[np.ndarray]:
    """
    Convert exactly WINDOW_SIZE pairs into a window tensor.
    Shape: [WINDOW_SIZE, 11]
    """
    if len(pairs) < WINDOW_SIZE:
        return None
    selected = pairs[-WINDOW_SIZE:]
    vecs = [p.to_vector() for p in selected]
    return np.stack(vecs, axis=0)


def extract_statistical_features(window: np.ndarray) -> np.ndarray:
    """
    Extract 43 statistical features from a window of shape [WINDOW_SIZE, 11].
    - 33 metrics for dwell (col 0), flight (col 1), digraph (col 2):
      mean, std, skewness, kurtosis, min, max, p10, p25, p50, p75, p90.
    - 5 metrics for key category proportions (cols 3-7).
    - 1 metric for standard deviation of key category proportions.
    - 2 metrics for digraph weights (col 10): mean, std.
    - 2 metrics for cyclical time encoding (cols 8-9): mean time_sin, mean time_cos.
    """
    features = []

    # 1. Dwell, Flight, Digraph
    for col_idx in [0, 1, 2]:
        data = window[:, col_idx]
        mean = float(np.mean(data))
        std = float(np.std(data)) + 1e-8
        
        # Scipy skew and kurtosis can return float arrays or floats, cast to float
        skew = float(scipy.stats.skew(data))
        kurt = float(scipy.stats.kurtosis(data))
        minimum = float(np.min(data))
        maximum = float(np.max(data))

        p10 = float(np.percentile(data, 10))
        p25 = float(np.percentile(data, 25))
        p50 = float(np.percentile(data, 50))
        p75 = float(np.percentile(data, 75))
        p90 = float(np.percentile(data, 90))

        features.extend([mean, std, skew, kurt, minimum, maximum, p10, p25, p50, p75, p90])

    # 2. Key category proportions
    cat_data = window[:, 3:8]  # shape [WINDOW_SIZE, 5]
    cat_proportions = np.mean(cat_data, axis=0)  # shape [5]
    features.extend(cat_proportions.tolist())
    features.append(float(np.std(cat_proportions)))

    # 3. Digraph weights
    weights = window[:, 10]
    features.extend([float(np.mean(weights)), float(np.std(weights)) + 1e-8])

    # 4. Time encoding
    time_sin = window[:, 8]
    time_cos = window[:, 9]
    features.extend([float(np.mean(time_sin)), float(np.mean(time_cos))])

    return np.array(features, dtype=np.float32)


# ── mouse feature extraction ──────────────────────────────────────────────────

def compute_speed(e1: MouseEvent, e2: MouseEvent) -> float:
    if e2.timestamp <= e1.timestamp:
        return 0.0
    dx = e2.x - e1.x
    dy = e2.y - e1.y
    dist = math.sqrt(dx*dx + dy*dy)
    dt = e2.timestamp - e1.timestamp
    return dist / dt  # px/s


def compute_angle(e1: MouseEvent, e2: MouseEvent) -> float:
    dx = e2.x - e1.x
    dy = e2.y - e1.y
    return math.atan2(dy, dx)  # radians


def compute_curvature(e1: MouseEvent, e2: MouseEvent, e3: MouseEvent) -> float:
    v1 = (e2.x - e1.x, e2.y - e1.y)
    v2 = (e3.x - e2.x, e3.y - e2.y)
    cross = v1[0] * v2[1] - v1[1] * v2[0]
    norm = math.sqrt(v1[0]**2 + v1[1]**2) * math.sqrt(v2[0]**2 + v2[1]**2)
    if norm < 1e-6:
        return 0.0
    return cross / norm


@dataclass
class MouseFeatureEvent:
    speed: float
    acceleration: float
    curvature: float
    angular_velocity: float
    action: str
    click_dwell_ms: float
    scroll_dy: float
    timestamp: float

    def to_vector(self) -> np.ndarray:
        t_sin, t_cos = encode_time(self.timestamp)
        vec = (
            [self.speed, self.acceleration, self.curvature,
             self.angular_velocity]
            + action_onehot(self.action)            # 5 dims
            + [self.click_dwell_ms, self.scroll_dy, t_sin, t_cos]
        )
        return np.array(vec, dtype=np.float32)      # shape [14]


def extract_mouse_features(events: list[MouseEvent]) -> list[MouseFeatureEvent]:
    features = []
    prev_speed = 0.0
    prev_angle = 0.0

    for i in range(1, len(events) - 1):
        e_prev, e_curr, e_next = events[i-1], events[i], events[i+1]

        speed = compute_speed(e_prev, e_curr)
        acceleration = speed - prev_speed

        angle = compute_angle(e_prev, e_curr)
        angular_vel = angle - prev_angle

        curvature = compute_curvature(e_prev, e_curr, e_next)

        click_dwell = 0.0
        if e_curr.action in ("PC", "C") and e_curr.press_ts is not None:
            click_dwell = (e_curr.timestamp - e_curr.press_ts) * 1000.0
            click_dwell = max(0.0, min(click_dwell, 5000.0))

        features.append(MouseFeatureEvent(
            speed=speed,
            acceleration=acceleration,
            curvature=curvature,
            angular_velocity=angular_vel,
            action=e_curr.action,
            click_dwell_ms=click_dwell,
            scroll_dy=e_curr.scroll_dy,
            timestamp=e_curr.timestamp,
        ))

        prev_speed = speed
        prev_angle = angle

    return features


def mouse_to_window(features: list[MouseFeatureEvent]) -> Optional[np.ndarray]:
    if len(features) < MOUSE_WINDOW_SIZE:
        return None
    selected = features[-MOUSE_WINDOW_SIZE:]
    vecs = [f.to_vector() for f in selected]
    return np.stack(vecs, axis=0)


# ── normalisation ─────────────────────────────────────────────────────────────

class WindowNormalizer:
    """
    Per-user normalizer for flat statistical feature vectors.
    Fits on enrollment features, then normalizes live features.
    """

    def __init__(self):
        self.mean: Optional[np.ndarray] = None
        self.std: Optional[np.ndarray] = None
        self._fitted = False

    def fit(self, features: list[np.ndarray]):
        """Fit on a list of statistical feature vectors. Shape: [N, F]"""
        stacked = np.stack(features, axis=0)   # [N, F]
        self.mean = stacked.mean(axis=0)
        self.std  = stacked.std(axis=0) + 1e-8      # avoid div by zero
        self._fitted = True

    def transform(self, feature: np.ndarray) -> np.ndarray:
        """Normalize a statistical feature vector. Shape: [F] → [F]"""
        if not self._fitted:
            raise RuntimeError("Normalizer not fitted — call fit() on enrollment data first")
        return (feature - self.mean) / self.std

    def fit_transform(self, features: list[np.ndarray]) -> list[np.ndarray]:
        self.fit(features)
        return [self.transform(f) for f in features]

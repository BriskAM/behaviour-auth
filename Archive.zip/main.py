"""
main.py — CLI entry point for BehaveGuard (SVM approach)

Usage:
    python main.py enroll --subject s001
    python main.py monitor --subject s001
    python main.py status --subject s001
"""

import argparse
import os
import pickle
import time

PROFILE_DIR = os.path.expanduser("~/.behaveguard/profiles")


def cmd_enroll(args):
    from enroll import run_enrollment
    os.makedirs(PROFILE_DIR, exist_ok=True)

    result = run_enrollment(
        subject_id=args.subject,
        device="cpu",
    )

    # save profile
    profile_path = os.path.join(PROFILE_DIR, f"{args.subject}.pkl")
    with open(profile_path, "wb") as f:
        pickle.dump(result.profile, f)

    print(f"\nProfile saved: {profile_path}")


def cmd_monitor(args):
    from collector import RawCollector
    from scorer import SessionScorer

    profile_path = os.path.join(PROFILE_DIR, f"{args.subject}.pkl")
    if not os.path.exists(profile_path):
        print(f"No profile found for '{args.subject}'. Run enroll first.")
        return

    with open(profile_path, "rb") as f:
        profile = pickle.load(f)

    collector = RawCollector()
    collector.start()
    scorer = SessionScorer(profile)

    print(f"\nMonitoring '{args.subject}'. Press Ctrl+C to stop.\n")
    
    last_printed_idx = -1

    try:
        while True:
            kb_events, _ = collector.drain()
            if kb_events:
                scorer.ingest_key_events(kb_events)

            # print window results only when a new window arrives
            results = scorer._window_results
            if results and len(results) > last_printed_idx + 1:
                for idx in range(last_printed_idx + 1, len(results)):
                    latest = results[idx]
                    bar = _score_bar(latest.combined_score, profile.T_anomaly)
                    print(
                        f"  window {latest.index:03d} | "
                        f"score={latest.combined_score:.4f} | "
                        f"T={latest.threshold_used:.4f} | "
                        f"{bar} | {latest.verdict.value}"
                    )
                    last_printed_idx = idx

            time.sleep(0.5)

    except KeyboardInterrupt:
        collector.stop()
        result = scorer.get_session_result()
        print("\n─── Session Summary ───")
        print(f"  Windows scored  : {result.n_windows}")
        print(f"  Anomaly rate    : {result.anomaly_rate:.1%}")
        print(f"  Mean score      : {result.mean_score:.4f}")
        print(f"  Verdict         : {result.verdict.value}")
        print(f"  FP category     : {result.fp_category.value}")
        print(f"  Action          : {result.recommended_action.value}")


def cmd_status(args):
    profile_path = os.path.join(PROFILE_DIR, f"{args.subject}.pkl")
    if not os.path.exists(profile_path):
        print(f"No profile for '{args.subject}'.")
        return

    with open(profile_path, "rb") as f:
        profile = pickle.load(f)

    enrolled_at = time.strftime("%Y-%m-%d %H:%M",
                                 time.localtime(profile.enrolled_at))
    print(f"\nProfile: {args.subject}")
    print(f"  Enrolled at    : {enrolled_at}")
    print(f"  Model version  : {profile.model_version}")
    print(f"  T_anomaly      : {profile.T_anomaly:.4f}")
    print(f"  T_drift        : {profile.T_drift:.4f}")
    
    # print statistical feature dimensions
    feat_dim = profile.normalizer.mean.shape[0] if profile.normalizer.mean is not None else 0
    print(f"  Feature dim    : {feat_dim}")
    
    if profile.last_retrain:
        last = time.strftime("%Y-%m-%d %H:%M",
                              time.localtime(profile.last_retrain))
        print(f"  Last retrain   : {last}")
    else:
        print(f"  Last retrain   : never")


def _score_bar(score: float, threshold: float) -> str:
    """Visual score bar for terminal output."""
    # Ensure threshold isn't zero to avoid DivisionByZero
    denom = threshold if threshold != 0 else 1.0
    filled = min(int(score / denom * 20), 20)
    bar = "█" * filled + "░" * (20 - filled)
    if score < threshold * 0.7:
        return f"[\033[92m{bar}\033[0m]"   # green
    elif score < threshold:
        return f"[\033[93m{bar}\033[0m]"   # yellow
    else:
        return f"[\033[91m{bar}\033[0m]"   # red


def main():
    parser = argparse.ArgumentParser(description="BehaveGuard — behavioral authentication")
    subparsers = parser.add_subparsers(dest="command")

    enroll_p = subparsers.add_parser("enroll", help="Run enrollment (5 min typing test)")
    enroll_p.add_argument("--subject", required=True, help="Subject ID")

    monitor_p = subparsers.add_parser("monitor", help="Continuous monitoring")
    monitor_p.add_argument("--subject", required=True, help="Subject ID")

    status_p = subparsers.add_parser("status", help="Show profile info")
    status_p.add_argument("--subject", required=True, help="Subject ID")

    args = parser.parse_args()

    if args.command == "enroll":
        cmd_enroll(args)
    elif args.command == "monitor":
        cmd_monitor(args)
    elif args.command == "status":
        cmd_status(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

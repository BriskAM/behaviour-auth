"""
model.py — One-Class SVM for behavioral authentication
"""

import numpy as np
from sklearn.svm import OneClassSVM
from dataclasses import dataclass
from typing import Optional

from features import extract_statistical_features, WindowNormalizer


# ── profile ───────────────────────────────────────────────────────────────────

@dataclass
class UserProfile:
    """
    Stores everything needed to score a user session using One-Class SVM.
    """
    subject_id: str
    model: OneClassSVM
    normalizer: WindowNormalizer

    # thresholds
    T_anomaly: float                        # 95th pct of calibration anomaly scores
    T_drift: float                          # 3x natural calibration variance (Mahalanobis distance)

    # enrollment statistics (used for drift detection)
    enrollment_mean: np.ndarray            # [F] mean of normalized statistical features
    enrollment_cov: np.ndarray             # [F, F] covariance matrix

    # metadata
    enrolled_at: float = 0.0
    model_version: int = 1
    last_retrain: Optional[float] = None

    def score_window(self, raw_window: np.ndarray) -> dict:
        """
        Score a single raw window of shape [WINDOW_SIZE, 11].
        1. Extract flat statistical features [43]
        2. Normalize using the profile's normalizer
        3. Score using the OneClassSVM
        """
        # 1. extract statistical features
        stat = extract_statistical_features(raw_window)
        
        # 2. normalize
        normed = self.normalizer.transform(stat)
        
        # 3. score using OneClassSVM (decision_function returns distance to hyperplane)
        # We invert it so that:
        #  - Inliers (legitimate) have lower values (neg/low)
        #  - Outliers (anomaly) have higher values (pos)
        decision = float(self.model.decision_function(normed.reshape(1, -1))[0])
        combined = -decision

        return {
            "recon_error": combined,          # mapped to recon_error for compatibility with scorer
            "latent_distance": 0.0,           # placeholder for SVM
            "combined_score": combined,
            "is_anomaly": combined > self.T_anomaly,
        }


# ── training ──────────────────────────────────────────────────────────────────

def train_svm_model(normed_features: list[np.ndarray],
                    kernel: str = "rbf",
                    nu: float = 0.05,
                    gamma: str = "scale") -> OneClassSVM:
    """
    Train a One-Class SVM on pre-normalized statistical features.
    """
    X = np.stack(normed_features, axis=0)
    model = OneClassSVM(kernel=kernel, nu=nu, gamma=gamma)
    model.fit(X)
    return model


# ── threshold calibration ─────────────────────────────────────────────────────

def calibrate_svm_thresholds(model: OneClassSVM,
                             normalizer: WindowNormalizer,
                             val_raw_windows: list[np.ndarray],
                             percentile: float = 95.0,
                             drift_multiplier: float = 3.0) -> tuple:
    """
    Compute T_anomaly, T_drift, enrollment_mean, and enrollment_cov
    from held-out calibration windows.
    """
    # extract statistical features and normalize
    val_stats = [extract_statistical_features(w) for w in val_raw_windows]
    val_normed = [normalizer.transform(s) for s in val_stats]
    
    # compute anomaly scores (-decision_function)
    X_val = np.stack(val_normed, axis=0)
    decisions = model.decision_function(X_val)
    scores = -decisions
    
    T_anomaly = float(np.percentile(scores, percentile))
    
    # compute mahalanobis-based drift threshold
    enrollment_mean = X_val.mean(axis=0)
    enrollment_cov = np.cov(X_val.T) + np.eye(X_val.shape[1]) * 1e-6

    try:
        cov_inv = np.linalg.inv(enrollment_cov)
        dists = []
        for i in range(len(val_normed)):
            diff = X_val[i] - enrollment_mean
            d = float(np.sqrt(diff @ cov_inv @ diff))
            dists.append(d)
        T_drift = float(np.percentile(dists, percentile) * drift_multiplier)
    except np.linalg.LinAlgError:
        T_drift = float(np.std(scores) * drift_multiplier * 10)

    return T_anomaly, T_drift, enrollment_mean, enrollment_cov
